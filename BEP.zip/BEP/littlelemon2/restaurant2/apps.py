from django.apps import AppConfig


class Restaurant2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'restaurant2'
